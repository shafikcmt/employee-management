@extends('layouts.app')
@section('title','Take Attendance')
@section('content')
<style>
    .attendance-page{--brand:#0f766e;--brand-dark:#115e59;--soft:#f8fafc;--line:#e2e8f0;--ink:#0f172a;--muted:#64748b;}
    .attendance-hero{background:linear-gradient(135deg,#0f766e,#14b8a6 55%,#0ea5e9);border-radius:28px;color:#fff;box-shadow:0 22px 45px rgba(15,118,110,.22);overflow:hidden;position:relative;}
    .attendance-hero:after{content:"";position:absolute;inset:auto -70px -90px auto;width:260px;height:260px;border-radius:999px;background:rgba(255,255,255,.16);} 
    .attendance-panel{background:#fff;border:1px solid var(--line);border-radius:24px;box-shadow:0 14px 35px rgba(15,23,42,.07);} 
    .attendance-input{border:1px solid #cbd5e1;border-radius:16px;padding:.76rem .95rem;background:#fff;outline:none;width:100%;transition:.18s ease;} 
    .attendance-input:focus{border-color:#14b8a6;box-shadow:0 0 0 4px rgba(20,184,166,.14);} 
    .attendance-btn{border:1px solid #cbd5e1;border-radius:16px;padding:.72rem 1rem;font-weight:800;font-size:.86rem;background:#fff;color:#0f172a;transition:.18s ease;display:inline-flex;align-items:center;justify-content:center;gap:.45rem;white-space:nowrap;} 
    .attendance-btn:hover{transform:translateY(-1px);box-shadow:0 8px 20px rgba(15,23,42,.08);} 
    .attendance-btn-primary{background:#0f766e;color:#fff;border-color:#0f766e;} 
    .attendance-btn-primary:hover{background:#115e59;} 
    .attendance-btn-danger{background:#fee2e2;color:#991b1b;border-color:#fecaca;} 
    .attendance-btn-warning{background:#fef3c7;color:#92400e;border-color:#fde68a;} 
    .attendance-btn-blue{background:#dbeafe;color:#1e40af;border-color:#bfdbfe;} 
    .attendance-chip{border-radius:999px;padding:.38rem .72rem;font-size:.75rem;font-weight:900;display:inline-flex;align-items:center;gap:.35rem;} 
    .employee-card{border:1px solid #e2e8f0;border-radius:24px;background:#fff;box-shadow:0 12px 28px rgba(15,23,42,.055);transition:.18s ease;overflow:hidden;} 
    .employee-card:hover{box-shadow:0 18px 38px rgba(15,23,42,.09);transform:translateY(-1px);} 
    .employee-card.is-present{border-color:#99f6e4;background:linear-gradient(180deg,#f0fdfa,#fff 45%);} 
    .employee-card.is-absent{border-color:#fecaca;background:linear-gradient(180deg,#fff1f2,#fff 45%);} 
    .employee-card.is-extra{border-color:#fde68a;background:linear-gradient(180deg,#fffbeb,#fff 45%);} 
    .status-grid{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:.45rem;} 
    .status-btn{border:1px solid #dbe3ef;background:#fff;border-radius:14px;padding:.68rem .5rem;text-align:center;font-weight:900;font-size:.78rem;color:#334155;transition:.16s ease;} 
    .status-btn:hover{background:#f8fafc;} 
    .status-btn.active[data-status="present"]{background:#0f766e;color:#fff;border-color:#0f766e;} 
    .status-btn.active[data-status="absent"]{background:#dc2626;color:#fff;border-color:#dc2626;} 
    .status-btn.active[data-status="friday"]{background:#f59e0b;color:#fff;border-color:#f59e0b;} 
    .status-btn.active[data-status="public_holiday"]{background:#2563eb;color:#fff;border-color:#2563eb;} 
    .status-btn.active[data-status="not_working"]{background:#475569;color:#fff;border-color:#475569;} 
    .easy-savebar{position:sticky;bottom:14px;z-index:30;border:1px solid #ccfbf1;background:rgba(255,255,255,.94);backdrop-filter:blur(12px);border-radius:22px;box-shadow:0 18px 45px rgba(15,23,42,.18);} 
    .mini-stat{border-radius:20px;border:1px solid #e2e8f0;background:#fff;padding:1rem;}
    .extra-box{border:1px dashed #f59e0b;background:#fffbeb;border-radius:18px;padding:.75rem;}
    @media(max-width:780px){.status-grid{grid-template-columns:repeat(2,minmax(0,1fr));}.attendance-hero{border-radius:22px}.employee-card{border-radius:20px}.easy-savebar{bottom:8px}.hide-mobile{display:none}}
</style>

<div class="attendance-page space-y-5">
    <section class="attendance-hero p-5 md:p-7">
        <div class="relative z-10 grid gap-5 xl:grid-cols-[1.1fr_.9fr] xl:items-end">
            <div>
                <div class="attendance-chip bg-white/15 text-white ring-1 ring-white/25">Daily Attendance Control</div>
                <h2 class="mt-3 text-2xl font-black md:text-4xl">Fast attendance, less typing.</h2>
                <p class="mt-2 max-w-2xl text-sm leading-6 text-teal-50 md:text-base">
                    Select project and date, mark employees with one click, enter hours, and save. Friday duty and extra duty can be handled from the same screen.
                </p>
                <div class="mt-4 flex flex-wrap gap-2 text-xs font-bold text-white/95">
                    <span class="attendance-chip bg-white/15">1. Load employees</span>
                    <span class="attendance-chip bg-white/15">2. Mark status</span>
                    <span class="attendance-chip bg-white/15">3. Save attendance</span>
                </div>
            </div>

            <form class="rounded-3xl bg-white/95 p-4 text-slate-900 shadow-xl" method="get">
                <div class="grid gap-3 md:grid-cols-[1fr_180px_180px] md:items-end">
                    <div>
                        <label class="text-xs font-black uppercase tracking-wide text-slate-500">Project</label>
                        <select name="project_id" class="attendance-input mt-1" onchange="this.form.submit()">
                            <option value="">All Active Employees</option>
                            @foreach($projects as $project)
                                <option value="{{ $project->id }}" @selected($projectId == $project->id)>{{ $project->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label class="text-xs font-black uppercase tracking-wide text-slate-500">Date</label>
                        <input class="attendance-input mt-1" type="date" name="date" value="{{ $date->toDateString() }}">
                    </div>
                    <button class="attendance-btn attendance-btn-primary h-[48px]">Load Employees</button>
                </div>
            </form>
        </div>
    </section>

    @if($isFriday)
        <div class="attendance-panel border-amber-200 bg-amber-50 p-4 text-sm font-bold text-amber-800">
            Friday selected: if you enter worked hours, the system will automatically treat it as Friday duty / extra duty.
        </div>
    @endif

    <form method="post" action="{{ route('attendance.bulk-store') }}" id="attendanceForm" class="space-y-5">
        @csrf
        <input type="hidden" name="attendance_date" value="{{ $date->toDateString() }}">
        <input type="hidden" name="project_id" value="{{ $projectId }}">

        <section class="attendance-panel p-4 md:p-5">
            <div class="grid gap-4 xl:grid-cols-[1fr_auto] xl:items-center">
                <div>
                    <h2 class="text-xl font-black text-slate-950">{{ $date->format('l, d M Y') }}</h2>
                    <p class="mt-1 text-sm text-slate-500">{{ $employees->count() }} active employee(s) loaded. Search, mark, then save once.</p>
                </div>
                <div class="flex flex-wrap gap-2">
                    <button type="button" class="attendance-btn attendance-btn-primary" onclick="markAll('present')">✓ All Present</button>
                    <button type="button" class="attendance-btn attendance-btn-danger" onclick="markAll('absent')">✕ All Absent</button>
                    <button type="button" class="attendance-btn attendance-btn-warning" onclick="markAll('friday')">Fri All</button>
                    <button type="button" class="attendance-btn attendance-btn-blue" onclick="markAll('public_holiday')">PH All</button>
                    <button type="submit" class="attendance-btn attendance-btn-primary">Save</button>
                </div>
            </div>

            <div class="mt-5 grid gap-3 md:grid-cols-4">
                <div class="mini-stat">
                    <div class="text-xs font-black uppercase text-slate-400">Employees</div>
                    <div class="mt-1 text-3xl font-black text-slate-950" id="statTotal">{{ $employees->count() }}</div>
                </div>
                <div class="mini-stat">
                    <div class="text-xs font-black uppercase text-emerald-600">Present</div>
                    <div class="mt-1 text-3xl font-black text-emerald-700" id="statPresent">0</div>
                </div>
                <div class="mini-stat">
                    <div class="text-xs font-black uppercase text-red-600">Absent</div>
                    <div class="mt-1 text-3xl font-black text-red-700" id="statAbsent">0</div>
                </div>
                <div class="mini-stat">
                    <div class="text-xs font-black uppercase text-amber-600">Extra Duty</div>
                    <div class="mt-1 text-3xl font-black text-amber-700" id="statExtra">0</div>
                </div>
            </div>

            <div class="mt-5 grid gap-3 lg:grid-cols-[1fr_180px_auto] lg:items-end">
                <div>
                    <label class="text-xs font-black uppercase tracking-wide text-slate-500">Search employee</label>
                    <input id="employeeSearch" class="attendance-input mt-1" type="search" placeholder="Type name, iqama, designation or company..." oninput="filterEmployees()">
                </div>
                <div>
                    <label class="text-xs font-black uppercase tracking-wide text-slate-500">Default hours</label>
                    <input id="defaultHours" class="attendance-input mt-1" type="number" step="0.01" min="0" value="8">
                </div>
                <div class="flex flex-wrap gap-2">
                    <button type="button" class="attendance-btn" onclick="clearAllRows()">Clear All</button>
                    <button type="button" class="attendance-btn" onclick="showOnly('all')">Show All</button>
                    <button type="button" class="attendance-btn" onclick="showOnly('absent')">Only Absent</button>
                    <button type="button" class="attendance-btn" onclick="showOnly('extra')">Only Extra</button>
                </div>
            </div>
        </section>

        <section class="grid gap-4 md:grid-cols-2 2xl:grid-cols-3" id="employeeGrid">
            @forelse($employees as $index => $employee)
                @php($record = $records->get($employee->id))
                @php($currentStatus = optional($record)->status ?? 'empty')
                @php($isExtra = (bool) (optional($record)->is_extra_duty ?? false))
                @php($searchText = strtolower(trim($employee->name.' '.$employee->iqama_no.' '.optional($employee->designation)->name.' '.optional($employee->company)->name.' '.optional($employee->currentProject)->name)))
                <article class="employee-card attendance-row p-4 {{ $currentStatus === 'present' ? 'is-present' : '' }} {{ $currentStatus === 'absent' ? 'is-absent' : '' }} {{ $isExtra ? 'is-extra' : '' }}" data-search="{{ $searchText }}" data-row-status="{{ $currentStatus }}" data-extra="{{ $isExtra ? '1' : '0' }}">
                    <input type="hidden" name="employee_ids[]" value="{{ $employee->id }}">
                    <select name="status[{{ $employee->id }}]" class="status-select hidden">
                        @foreach(['empty'=>'Empty','present'=>'Present','absent'=>'Absent','friday'=>'Friday','public_holiday'=>'Public Holiday','not_working'=>'Not Working'] as $value => $label)
                            <option value="{{ $value }}" @selected($currentStatus === $value)>{{ $label }}</option>
                        @endforeach
                    </select>

                    <div class="flex items-start gap-3">
                        <div class="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-teal-700 text-lg font-black text-white">{{ $index + 1 }}</div>
                        <div class="min-w-0 flex-1">
                            <div class="truncate text-base font-black text-slate-950">{{ $employee->name }}</div>
                            <div class="mt-1 flex flex-wrap gap-1 text-xs text-slate-500">
                                <span class="attendance-chip bg-slate-100 text-slate-600">Iqama: {{ $employee->iqama_no ?: '-' }}</span>
                                <span class="attendance-chip bg-slate-100 text-slate-600">{{ optional($employee->designation)->name ?: 'No designation' }}</span>
                            </div>
                            <div class="mt-1 text-xs font-semibold text-slate-400">Project: {{ optional($employee->currentProject)->name ?: '-' }}</div>
                        </div>
                        <span class="status-label attendance-chip bg-slate-100 text-slate-600">{{ ucfirst(str_replace('_',' ', $currentStatus)) }}</span>
                    </div>

                    <div class="mt-4 status-grid">
                        <button type="button" class="status-btn" data-status="present" onclick="setStatus(this,'present')">Present</button>
                        <button type="button" class="status-btn" data-status="absent" onclick="setStatus(this,'absent')">Absent</button>
                        <button type="button" class="status-btn" data-status="friday" onclick="setStatus(this,'friday')">Friday</button>
                        <button type="button" class="status-btn" data-status="public_holiday" onclick="setStatus(this,'public_holiday')">PH</button>
                        <button type="button" class="status-btn" data-status="not_working" onclick="setStatus(this,'not_working')">NW</button>
                    </div>

                    <div class="mt-4 grid gap-3 sm:grid-cols-2">
                        <div>
                            <label class="text-xs font-black uppercase tracking-wide text-slate-500">Worked hours</label>
                            <input class="attendance-input hours-input mt-1 text-lg font-black" type="number" step="0.01" min="0" name="hours[{{ $employee->id }}]" value="{{ optional($record)->hours }}" placeholder="8" oninput="hoursChanged(this)">
                        </div>
                        <div>
                            <label class="text-xs font-black uppercase tracking-wide text-slate-500">Extra rate</label>
                            <input class="attendance-input rate-input mt-1" type="number" step="0.01" min="0" name="rate[{{ $employee->id }}]" value="{{ optional($record)->extra_duty_hours ? number_format((optional($record)->extra_duty_amount ?? 0) / max(optional($record)->extra_duty_hours, 1), 2, '.', '') : '' }}" placeholder="0">
                        </div>
                    </div>

                    <div class="extra-box mt-4">
                        <label class="flex cursor-pointer items-center justify-between gap-3">
                            <span>
                                <span class="block text-sm font-black text-amber-900">Extra / Friday Duty</span>
                                <span class="block text-xs text-amber-700">Use this when employee works on Friday, public holiday, or overtime.</span>
                            </span>
                            <input class="extra-checkbox h-5 w-5" type="checkbox" name="is_extra_duty[{{ $employee->id }}]" value="1" @checked($isExtra) onchange="extraChanged(this)">
                        </label>
                        <div class="mt-3 grid gap-3 sm:grid-cols-2">
                            <select name="extra_duty_type[{{ $employee->id }}]" class="attendance-input duty-type-input">
                                @foreach(['friday'=>'Friday Duty','public_holiday'=>'Public Holiday','off_day'=>'Off Day','normal_day'=>'Normal Overtime'] as $value => $label)
                                    <option value="{{ $value }}" @selected((optional($record)->extra_duty_type ?? ($isFriday ? 'friday' : 'normal_day')) === $value)>{{ $label }}</option>
                                @endforeach
                            </select>
                            <input class="attendance-input" name="remarks[{{ $employee->id }}]" value="{{ optional($record)->remarks }}" placeholder="Remarks">
                        </div>
                    </div>
                </article>
            @empty
                <div class="attendance-panel p-8 text-center text-slate-500 md:col-span-2 2xl:col-span-3">
                    No active employees found. Select another project or add employees first.
                </div>
            @endforelse
        </section>

        <div class="easy-savebar p-3 md:p-4">
            <div class="flex flex-wrap items-center justify-between gap-3">
                <div>
                    <div class="text-sm font-black text-slate-900">Ready to save attendance?</div>
                    <div class="text-xs text-slate-500"><span id="visibleCount">{{ $employees->count() }}</span> employee card(s) visible. Present: <b id="savePresent">0</b>, Absent: <b id="saveAbsent">0</b>, Extra: <b id="saveExtra">0</b>.</div>
                </div>
                <div class="flex flex-wrap gap-2">
                    <a class="attendance-btn" href="{{ route('attendance.index', ['project_id' => $projectId, 'month' => $date->month, 'year' => $date->year]) }}">Monthly Sheet</a>
                    <a class="attendance-btn" href="{{ route('absent.index', ['project_id' => $projectId, 'month' => $date->month, 'year' => $date->year]) }}">Absent Report</a>
                    <button class="attendance-btn attendance-btn-primary px-6">Save Attendance</button>
                </div>
            </div>
        </div>
    </form>
</div>

<script>
const isFriday = @json($isFriday);

function rowFromElement(element) {
    return element.closest('.attendance-row');
}

function statusText(status) {
    return {
        empty: 'Empty',
        present: 'Present',
        absent: 'Absent',
        friday: 'Friday',
        public_holiday: 'Public Holiday',
        not_working: 'Not Working'
    }[status] || 'Empty';
}

function setStatus(button, status) {
    const row = rowFromElement(button);
    applyStatus(row, status, true);
}

function applyStatus(row, status, fromButton = false) {
    const select = row.querySelector('.status-select');
    const hours = row.querySelector('.hours-input');
    const extra = row.querySelector('.extra-checkbox');
    const dutyType = row.querySelector('.duty-type-input');
    const defaultHours = document.getElementById('defaultHours')?.value || 8;

    select.value = status;
    row.dataset.rowStatus = status;
    row.querySelectorAll('.status-btn').forEach(btn => btn.classList.toggle('active', btn.dataset.status === status));
    row.querySelector('.status-label').textContent = statusText(status);

    if (status === 'present' && (!hours.value || fromButton)) {
        hours.value = defaultHours;
    }

    if (['absent','friday','public_holiday','not_working','empty'].includes(status)) {
        hours.value = '';
        if (status !== 'present') {
            extra.checked = false;
        }
    }

    if (status === 'friday') {
        dutyType.value = 'friday';
    }

    if (status === 'public_holiday') {
        dutyType.value = 'public_holiday';
    }

    updateRowStyle(row);
    updateStats();
}

function hoursChanged(input) {
    const row = rowFromElement(input);
    const status = row.querySelector('.status-select').value;
    const extra = row.querySelector('.extra-checkbox');
    const dutyType = row.querySelector('.duty-type-input');
    const hasHours = Number(input.value) > 0;

    if (hasHours && status !== 'present') {
        applyStatus(row, 'present');
    }

    if (hasHours && isFriday) {
        extra.checked = true;
        dutyType.value = 'friday';
    }

    updateRowStyle(row);
    updateStats();
}

function extraChanged(input) {
    const row = rowFromElement(input);
    if (input.checked) {
        const hours = row.querySelector('.hours-input');
        if (!hours.value) hours.value = document.getElementById('defaultHours')?.value || 8;
        applyStatus(row, 'present');
    }
    updateRowStyle(row);
    updateStats();
}

function updateRowStyle(row) {
    const status = row.querySelector('.status-select').value;
    const extra = row.querySelector('.extra-checkbox').checked;
    row.classList.toggle('is-present', status === 'present');
    row.classList.toggle('is-absent', status === 'absent');
    row.classList.toggle('is-extra', extra);
    row.dataset.extra = extra ? '1' : '0';
}

function markAll(status) {
    document.querySelectorAll('.attendance-row').forEach(row => {
        if (row.style.display === 'none') return;
        applyStatus(row, status, true);
    });
}

function clearAllRows() {
    document.querySelectorAll('.attendance-row').forEach(row => {
        row.querySelector('.hours-input').value = '';
        row.querySelector('.extra-checkbox').checked = false;
        applyStatus(row, 'empty');
    });
}

function filterEmployees() {
    const query = (document.getElementById('employeeSearch').value || '').toLowerCase().trim();
    let visible = 0;
    document.querySelectorAll('.attendance-row').forEach(row => {
        const matched = !query || row.dataset.search.includes(query);
        row.style.display = matched ? '' : 'none';
        if (matched) visible++;
    });
    document.getElementById('visibleCount').textContent = visible;
}

function showOnly(type) {
    let visible = 0;
    document.querySelectorAll('.attendance-row').forEach(row => {
        const status = row.querySelector('.status-select').value;
        const extra = row.querySelector('.extra-checkbox').checked;
        const matched = type === 'all' || status === type || (type === 'extra' && extra);
        row.style.display = matched ? '' : 'none';
        if (matched) visible++;
    });
    document.getElementById('employeeSearch').value = '';
    document.getElementById('visibleCount').textContent = visible;
}

function updateStats() {
    let present = 0, absent = 0, extra = 0, visible = 0;
    document.querySelectorAll('.attendance-row').forEach(row => {
        if (row.style.display !== 'none') visible++;
        const status = row.querySelector('.status-select').value;
        if (status === 'present') present++;
        if (status === 'absent') absent++;
        if (row.querySelector('.extra-checkbox').checked) extra++;
    });
    document.getElementById('statPresent').textContent = present;
    document.getElementById('statAbsent').textContent = absent;
    document.getElementById('statExtra').textContent = extra;
    document.getElementById('savePresent').textContent = present;
    document.getElementById('saveAbsent').textContent = absent;
    document.getElementById('saveExtra').textContent = extra;
    document.getElementById('visibleCount').textContent = visible;
}

document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.attendance-row').forEach(row => {
        applyStatus(row, row.querySelector('.status-select').value || 'empty');
        if (isFriday && Number(row.querySelector('.hours-input').value) > 0) {
            row.querySelector('.extra-checkbox').checked = true;
            row.querySelector('.duty-type-input').value = 'friday';
        }
        updateRowStyle(row);
    });
    updateStats();
});
</script>
@endsection
